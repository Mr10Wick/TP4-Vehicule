package com.dev;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class VehiculeRepositoryImplTest {

    @Test
    public void testFiltrerVehiculesMoinsDe20Ans() {
        // Créer un objet de la classe à tester
        VehiculeRepositoryImpl repository = new VehiculeRepositoryImpl();

        // Créer une liste de véhicules de test
        List<Vehicule> vehicules = new ArrayList<>();
        // Ajoutez des véhicules avec différents âges
        vehicules.add(new Vehicule("AX123P1", "tesla", "X", getDateYearsAgo(5), 40000.00)); // Moins de 20 ans
        vehicules.add(new Vehicule("AX123P2", "toyota", "corolla", getDateYearsAgo(25), 4500.00)); // Plus de 20 ans
        vehicules.add(new Vehicule("AX123P3", "toyota", "avensis", getDateYearsAgo(15), 70000.00)); // Moins de 20 ans

        // Appeler la méthode de filtre
        List<Vehicule> vehiculesFiltres = repository.filtrerVehiculesMoinsDe20Ans(vehicules);

        // Vérifier le résultat
        assertEquals(2, vehiculesFiltres.size()); // Il devrait y avoir deux véhicules de moins de 20 ans
        // Vous pouvez ajouter plus d'assertions pour vérifier les détails des véhicules filtrés si nécessaire
    }

    // Méthode utilitaire pour obtenir une date d'il y a n années
    private Date getDateYearsAgo(int years) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -years);
        return calendar.getTime();
    }
}
