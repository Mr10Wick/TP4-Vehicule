package com.dev;

import java.sql.SQLException;
import java.util.List;

public class App {

    private VehiculeRepositoryImpl vehiculeRepository;

    public App(VehiculeRepositoryImpl vehiculeRepository) {
        this.vehiculeRepository = vehiculeRepository;
    }

    public List<Vehicule> getAllVehicules() throws ClassNotFoundException, SQLException {
        return vehiculeRepository.lireVehiculesDepuisFichier();
    }

    public List<Vehicule> getVehiculesMoinsDe20Ans(List<Vehicule> vehicules) {
        return vehiculeRepository.filtrerVehiculesMoinsDe20Ans(vehicules);
    }
}
