package com.dev;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.dev.App.isVehiculeMoinsDe20Ans;

public class VehiculeRepositoryImpl {


    public List<Vehicule> lireVehiculesDepuisFichier() {
        List<Vehicule> vehicules = new ArrayList<>();
        String nomFichier = "data.txt";
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        try (BufferedReader reader = new BufferedReader(new FileReader(nomFichier))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String immatriculation = parts[0];
                String marque = parts[1];
                String modele = parts[2];
                Date dateMiseEnCirculation = dateFormat.parse(parts[3]);
                double prixVente = Double.parseDouble(parts[4]);

                Vehicule vehicule = new Vehicule(immatriculation, marque, modele, dateMiseEnCirculation, prixVente);
                vehicules.add(vehicule);
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return vehicules;
    }

    public void insererVehiculesMoinsDe20AnsDansDB(List<Vehicule> vehicules) {
        List<Vehicule> vehiculesMoinsDe20Ans = vehicules.stream()
                .filter(vehicule -> isVehiculeMoinsDe20Ans(vehicule))
                .collect(Collectors.toList());

        String insertQuery = "INSERT INTO car (registration_number, brand, model, date_of_first_registration, price) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = new ClientDBConfig().getConnection();
             PreparedStatement statement = connection.prepareStatement(insertQuery)) {

            for (Vehicule vehicule : vehiculesMoinsDe20Ans) {
                statement.setString(1, vehicule.getImmatriculation());
                statement.setString(2, vehicule.getMarque());
                statement.setString(3, vehicule.getModele());
                statement.setDate(4, new java.sql.Date(vehicule.getDateMiseEnCirculation().getTime()));
                statement.setDouble(5, vehicule.getPrixVente());
                statement.executeUpdate();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public List<Vehicule> filtrerVehiculesMoinsDe20Ans(List<Vehicule> vehicules) {
        List<Vehicule> vehiculesMoinsDe20Ans = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -20);
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getDateMiseEnCirculation().after(cal.getTime())) {
                vehiculesMoinsDe20Ans.add(vehicule);
            }
        }

        return vehiculesMoinsDe20Ans;
    }

    public void ecrireVehiculesDansFichier(List<Vehicule> vehicules) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt"))) {
            for (Vehicule vehicule : vehicules) {
                writer.println(vehicule.toCsv());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public List<Vehicule> vehiculesAgeDonne(int age) {
        List<Vehicule> vehiculesAgeDonne = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -age); // Obtenez la date d'il y a 'age' années
        for (Vehicule vehicule : lireVehiculesDepuisFichier()) {
            if (vehicule.getDateMiseEnCirculation().after(calendar.getTime())) {
                vehiculesAgeDonne.add(vehicule);
            }
        }
        return vehiculesAgeDonne;
    }
}
