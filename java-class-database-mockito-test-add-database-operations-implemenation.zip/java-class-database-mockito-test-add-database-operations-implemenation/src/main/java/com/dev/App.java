package com.dev;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.dev.VehiculeRepositoryImpl;

public class App {
    private static Scanner scanner;
    private static VehiculeRepositoryImpl vehiculeRepository;

    public static void main(String[] args) {

        VehiculeRepositoryImpl vehiculeRepository = new VehiculeRepositoryImpl();


        // Récupérer et afficher tous les véhicules
        System.out.println();
        System.out.println("Liste de tous les véhicules :");
        System.out.println();
        List<Vehicule> allVehicules = vehiculeRepository.lireVehiculesDepuisFichier();
        for (Vehicule vehicule : allVehicules) {
            System.out.println(vehicule);
        }

        System.out.println();
        System.out.println();
        System.out.println();

        // Filtrer et afficher les véhicules de moins de 20 ans
        System.out.println("Liste des véhicules de moins de 20 ans :");
        System.out.println();
        for (Vehicule vehicule : allVehicules) {
            if (isVehiculeMoinsDe20Ans(vehicule)) {
                System.out.println(vehicule);
            }
        }

        // Insérer les véhicules de moins de 20 ans dans la base de données
        vehiculeRepository.insererVehiculesMoinsDe20AnsDansDB(allVehicules);
        System.out.println();
        System.out.println("Insertion des véhicules de moins de 20 ans dans la base de données terminée.");

        // Initialisation du scanner
        scanner = new Scanner(System.in);

        // Appel de la méthode pour afficher le menu
        afficherMenu(allVehicules);
    }

    static boolean isVehiculeMoinsDe20Ans(Vehicule vehicule) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(vehicule.getDateMiseEnCirculation());
        calendar.add(Calendar.YEAR, 20);
        return calendar.getTime().after(new Date());
    }


    private static void afficherMenu(List<Vehicule> allVehicules) {
        boolean continuer = true;
        while (continuer) {
            System.out.println();
            System.out.println("Menu :");
            System.out.println("a. Afficher les véhicules");
            System.out.println("b. Modifier un véhicule");
            System.out.println("c. Ajouter un véhicule");
            System.out.println("d. Supprimer un véhicule");
            System.out.println("e. Afficher les véhicules d'un âge donné");
            System.out.println("f. Afficher les véhicules dont le prix est compris entre un prix minimal et un prix maximal");
            System.out.println("q. Quitter");
            System.out.print("Entrez votre choix : ");
            String choix = scanner.nextLine().toLowerCase();
            switch (choix) {
                case "a":
                    afficherTousVehicules(allVehicules);
                    break;
                case "b":
                    VehiculeManager.modifierVehicule(scanner, allVehicules);
                    break;
                case "c":
                    AddVehicule.ajouterVehicule(vehiculeRepository, allVehicules);
                    break;
                case "d":
                    VehiculeManager.supprimerVehicule(scanner, allVehicules);
                    break;
                case "e":
                    VehiculeManager.afficherVehiculesAgeDonne(scanner, allVehicules);
                    break;
                case "f":
                    //afficherVehiculesPrixCompris();
                    break;
                case "q":
                    continuer = false;
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }
    }

    private static void afficherTousVehicules(List<Vehicule> allVehicules) {
        System.out.println("Liste de tous les véhicules :");
        for (Vehicule vehicule : allVehicules) {
            System.out.println(vehicule);
        }
    }
}
