package com.dev;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Vehicule {
    private String immatriculation;
    private String marque;
    private String modele;
    private Date dateMiseEnCirculation;
    private double prixVente;

    public Vehicule(String immatriculation, String marque, String modele, Date dateMiseEnCirculation, double prixVente) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.dateMiseEnCirculation = dateMiseEnCirculation;
        this.prixVente = prixVente;
    }

    @Override
    public String toString() {
        return "Vehicule{" +
                "immatriculation='" + immatriculation + '\'' +
                ", marque='" + marque + '\'' +
                ", modele='" + modele + '\'' +
                ", dateMiseEnCirculation=" + dateMiseEnCirculation +
                ", prixVente=" + prixVente +
                '}';
    }

    public Date getDateMiseEnCirculation() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dateMiseEnCirculation);
        return calendar.getTime();
    }

    public double getPrixVente() {
        return prixVente;
    }

    public String getImmatriculation() {
        return immatriculation;
    }

    public String getModele() {
        return modele;
    }
    public String getMarque() {
        return marque;
    }
    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }
    public String toCsv() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        return immatriculation + "," + marque + "," + modele + "," + dateFormat.format(dateMiseEnCirculation) + "," + prixVente;
    }

}
