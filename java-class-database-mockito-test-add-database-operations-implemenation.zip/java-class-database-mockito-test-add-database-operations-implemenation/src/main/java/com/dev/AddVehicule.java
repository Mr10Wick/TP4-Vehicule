package com.dev;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class AddVehicule {
    private static Scanner scanner = new Scanner(System.in);

    public static void ajouterVehicule(VehiculeRepositoryImpl vehiculeRepository, List<Vehicule> allVehicules) {
        System.out.println("Ajout d'un nouveau véhicule :");
        System.out.print("Immatriculation : ");
        String immatriculation = scanner.nextLine();
        System.out.print("Marque : ");
        String marque = scanner.nextLine();
        System.out.print("Modèle : ");
        String modele = scanner.nextLine();
        System.out.print("Prix de vente : ");
        double prixVente = Double.parseDouble(scanner.nextLine());
        System.out.print("Date de mise en circulation (format JJ/MM/AAAA) : ");
        String dateStr = scanner.nextLine();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date dateMiseEnCirculation;
        try {
            dateMiseEnCirculation = dateFormat.parse(dateStr);
        } catch (ParseException e) {
            System.out.println("Format de date incorrect. Utilisez le format JJ/MM/AAAA.");
            return;
        }

        // Création d'un nouvel objet Vehicule avec les informations saisies par l'utilisateur
        Vehicule nouveauVehicule = new Vehicule(immatriculation, marque, modele, dateMiseEnCirculation, prixVente);

        // Ajouter le nouveau véhicule à la liste
        allVehicules.add(nouveauVehicule);

        // Mettre à jour le fichier texte
        vehiculeRepository.ecrireVehiculesDansFichier(allVehicules);

        System.out.println("Le véhicule a été ajouté avec succès.");
    }
}
