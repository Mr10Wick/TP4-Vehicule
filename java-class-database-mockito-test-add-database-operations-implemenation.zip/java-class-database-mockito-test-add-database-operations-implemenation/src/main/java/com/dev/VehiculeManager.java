package com.dev;

import java.util.List;
import java.util.Scanner;

public class VehiculeManager {
    public static void modifierVehicule(Scanner scanner, List<Vehicule> vehicules) {
        // Afficher la liste des véhicules
        System.out.println("Liste de tous les véhicules :");
        for (int i = 0; i < vehicules.size(); i++) {
            System.out.println((i + 1) + ". " + vehicules.get(i));
        }

        // Demander à l'utilisateur de saisir l'immatriculation du véhicule à modifier
        System.out.print("Entrez l'immatriculation du véhicule à modifier : ");
        String immatriculation = scanner.nextLine();

        // Recherche du véhicule correspondant à l'immatriculation saisie
        Vehicule vehicule = null;
        for (Vehicule v : vehicules) {
            if (v.getImmatriculation().equals(immatriculation)) {
                vehicule = v;
                break;
            }
        }

        // Vérifier si le véhicule a été trouvé
        if (vehicule == null) {
            System.out.println("Aucun véhicule trouvé avec l'immatriculation saisie.");
            return;
        }

        // Demander à l'utilisateur de saisir les nouvelles informations pour le véhicule
        System.out.println("Modifier le véhicule : " + vehicule);
        System.out.print("Nouvelle immatriculation : ");
        String nouvelleImmatriculation = scanner.nextLine();
        System.out.print("Nouvelle marque : ");
        String nouvelleMarque = scanner.nextLine();
        System.out.print("Nouveau modèle : ");
        String nouveauModele = scanner.nextLine();

        // Mettre à jour les détails du véhicule avec les nouvelles informations saisies par l'utilisateur
        vehicule.setImmatriculation(nouvelleImmatriculation);
        vehicule.setMarque(nouvelleMarque);
        vehicule.setModele(nouveauModele);

        System.out.println("Le véhicule a été modifié avec succès.");
    }
    public static void supprimerVehicule(Scanner scanner, List<Vehicule> vehicules) {
        System.out.print("Entrez l'immatriculation du véhicule à supprimer : ");
        String immatriculation = scanner.nextLine();

        boolean vehiculeTrouve = false;
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getImmatriculation().equals(immatriculation)) {
                vehicules.remove(vehicule);
                vehiculeTrouve = true;
                System.out.println("Le véhicule a été supprimé avec succès.");
                break;
            }
        }

        if (!vehiculeTrouve) {
            System.out.println("Aucun véhicule trouvé avec l'immatriculation saisie.");
        }
    }
    public static void afficherVehiculesAgeDonne(Scanner scanner, List<Vehicule> vehicules) {
        System.out.print("Entrez l'âge des véhicules à afficher : ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Pour consommer le retour à la ligne

        VehiculeRepositoryImpl vehiculeRepository = new VehiculeRepositoryImpl();
        List<Vehicule> vehiculesAgeDonne = vehiculeRepository.vehiculesAgeDonne(age);

        System.out.println("Liste des véhicules d'un âge de " + age + " ans :");
        for (Vehicule vehicule : vehiculesAgeDonne) {
            System.out.println(vehicule);
        }
    }


}